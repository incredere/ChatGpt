export interface Document {
  name: string;
  size: string;
  sha1: string;
}
