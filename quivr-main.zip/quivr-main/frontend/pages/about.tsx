const About = (): JSX.Element => {
  return <div>About</div>;
};

export default About;
