openai_function_compatible_models = [
    "gpt-3.5-turbo-0613",
    "gpt-4-0613",
]

streaming_compatible_models = ["gpt-3.5-turbo, gpt4all-j-1.3"]

private_models = ["gpt4all-j-1.3"]
